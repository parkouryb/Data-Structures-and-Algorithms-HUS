/* NomNom created on 5/9/2020 inside the package - CTDL.Homework_6.StockSystem */

package CTDL.Homework_6.StockSystem.Stock;

public interface Stock {

    String code();
    int tradeID();

    @Override
    String toString();
}
