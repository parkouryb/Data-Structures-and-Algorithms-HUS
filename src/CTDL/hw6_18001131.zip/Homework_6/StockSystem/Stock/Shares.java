package CTDL.Homework_6.StockSystem.Stock;

public enum Shares {
    AMZ,
    APL,
    MCR
}
