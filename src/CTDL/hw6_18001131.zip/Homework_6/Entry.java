/* NomNom created on 4/26/2020 inside the package - CTDL.Homework_6 */

package CTDL.Homework_6;

public interface Entry<K, E> {
    /**
     *
     * @return key
     */
    K getKey();

    /**
     *
     * @return value
     */
    E getValue();
}

